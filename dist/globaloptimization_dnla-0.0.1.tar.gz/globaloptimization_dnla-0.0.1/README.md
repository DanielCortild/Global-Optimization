# Global Optimization Algorithm DNLA

This is a preliminary readme file.